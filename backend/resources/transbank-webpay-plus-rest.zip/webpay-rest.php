<?php

use Transbank\WooCommerce\WebpayRest\Admin\Notices\DismissNoticeAjax;
use Transbank\WooCommerce\WebpayRest\Admin\Notices\NoticeInscriptionDelete;
use Transbank\WooCommerce\WebpayRest\Controllers\TransactionStatusController;
use Transbank\WooCommerce\WebpayRest\Helpers\DatabaseTableInstaller;
use Transbank\WooCommerce\WebpayRest\Helpers\SessionMessageHelper;
use Transbank\WooCommerce\WebpayRest\Helpers\HposHelper;
use Transbank\WooCommerce\WebpayRest\Helpers\TbkFactory;
use Transbank\WooCommerce\WebpayRest\PaymentGateways\WC_Gateway_Transbank_Oneclick_Mall_REST;
use Transbank\WooCommerce\WebpayRest\PaymentGateways\WC_Gateway_Transbank_Webpay_Plus_REST;
use Transbank\WooCommerce\WebpayRest\Blocks\WCGatewayTransbankWebpayBlocks;
use Transbank\WooCommerce\WebpayRest\Blocks\WCGatewayTransbankOneclickBlocks;
use Transbank\WooCommerce\WebpayRest\Setup\ConfigMigrator;
use Transbank\WooCommerce\WebpayRest\Utils\ConnectionCheck;
use Transbank\WooCommerce\WebpayRest\Utils\TableCheck;
use Transbank\Plugin\Helpers\PluginLogger;
use Transbank\WooCommerce\WebpayRest\Utils\Template;
use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;
use Transbank\WooCommerce\WebpayRest\Admin\Notices\AdminNoticeManager;
use Transbank\WooCommerce\WebpayRest\Admin\Notices\MissingWooCommerceNotice;
use Transbank\WooCommerce\WebpayRest\Admin\Notices\NoticeRenderer;
use Transbank\WooCommerce\WebpayRest\Admin\Notices\ReviewNotice;
use Transbank\WooCommerce\WebpayRest\Config\TransbankPluginSettings;
use Transbank\WooCommerce\WebpayRest\Setup\GatewaySettingsInstaller;

if (!defined('ABSPATH')) {
    return;
}
/**
 * The plugin bootstrap file.
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @wordpress-plugin
 * Plugin Name: Transbank Webpay
 * Plugin URI: https://www.transbankdevelopers.cl/plugin/woocommerce/webpay
 * Description: Recibe pagos en línea con Tarjetas de Crédito y Redcompra en tu WooCommerce a través de Webpay Plus y Webpay Oneclick.
 * Version: 1.12.2
 * Requires Plugins: woocommerce
 * Author: TransbankDevelopers
 * Author URI: https://www.transbank.cl
 * WC requires at least: 7.0
 * WC tested up to: 10.5.2
 */

require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
$hposHelper = new HposHelper();
$hposExists = $hposHelper->checkIfHposExists();
add_action('plugins_loaded', 'registerPaymentGateways', 0);
add_action('wp_loaded', 'woocommerceTransbankInit');
register_activation_hook(__FILE__, 'activateTransbankModule');
register_uninstall_hook(__FILE__, 'transbank_rest_remove_database');
add_action('add_meta_boxes', function () use ($hposExists) {
    addTransbankStatusMetaBox($hposExists);
});

add_action('init', function () {
    add_action('wp_ajax_check_connection', ConnectionCheck::class . '::check');
    add_action('wp_ajax_check_can_download_file', PluginLogger::class . '::checkCanDownloadLogFile');
    add_action('wp_ajax_download_log_file', PluginLogger::class . '::downloadLogFile');
    add_action('wp_ajax_get_transaction_status', [new TransactionStatusController(), 'getStatus']);
});

add_action('woocommerce_before_cart', 'transbank_rest_before_cart');

add_action('woocommerce_before_checkout_form', 'transbank_rest_check_cancelled_checkout');
add_action('admin_enqueue_scripts', function () {
    wp_enqueue_style('tbk-styles', plugins_url('/css/tbk.css', __FILE__), [], '1.1');
    wp_enqueue_style('tbk-font-awesome', plugins_url('/css/font-awesome/all.css', __FILE__));
    wp_enqueue_script('tbk-ajax-script', plugins_url('/js/admin.js', __FILE__), ['jquery']);
    wp_enqueue_script('tbk-thickbox', plugins_url('/js/swal.min.js', __FILE__));
    wp_localize_script('tbk-ajax-script', 'ajax_object', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('my-ajax-nonce'),
    ]);
});

add_action('woocommerce_blocks_loaded', function () {
    if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        require_once 'src/Blocks/WC_Gateway_Transbank_Webpay_Blocks.php';
        require_once 'src/Blocks/WC_Gateway_Transbank_Oneclick_Blocks.php';
        add_action(
            'woocommerce_blocks_payment_method_type_registration',
            function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
                $payment_method_registry->register(new WCGatewayTransbankWebpayBlocks());
                $payment_method_registry->register(new WCGatewayTransbankOneclickBlocks());
            }
        );
    }
});

add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

if ($hposExists) {
    add_action('before_woocommerce_init', function () {
        if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
                'custom_order_tables',
                __FILE__,
                true
            );
        }
    });
}


//Start sessions if not already done
add_action('init', function () {
    if (!headers_sent() && '' == session_id()) {
        session_start([
            'read_and_close' => true,
        ]);
    }
});

function woocommerceTransbankInit()
{
    registerAdminMenu();
    registerPluginActionLinks();

    $setting = new TransbankPluginSettings();
    $renderer = new NoticeRenderer(__FILE__);

    (new DismissNoticeAjax($setting))->register();
    (new AdminNoticeManager(
        new MissingWooCommerceNotice($renderer),
        new ReviewNotice($renderer, $setting),
        new NoticeInscriptionDelete($renderer)
    ))->register();
}

function registerPaymentGateways()
{
    add_filter('woocommerce_payment_gateways', function ($methods) {
        $methods[] = WC_Gateway_Transbank_Webpay_Plus_REST::class;
        $methods[] = WC_Gateway_Transbank_Oneclick_Mall_REST::class;
        return $methods;
    });

    ConfigMigrator::maybeMigrate();
}

function registerAdminMenu()
{
    add_action('admin_menu', function () {
        add_submenu_page('woocommerce', __('Configuración de Webpay Plus', 'transbank_wc_plugin'), 'Webpay Plus', 'administrator', 'transbank_webpay_plus_rest', function () {
            $tab = filter_input(INPUT_GET, 'tbk_tab', FILTER_DEFAULT) ?? '';
            $tab = htmlspecialchars($tab, ENT_QUOTES, 'UTF-8');
            if (!in_array($tab, ['healthcheck', 'logs', 'transactions', 'inscriptions'])) {
                wp_redirect(admin_url('admin.php?page=wc-settings&tab=checkout&section=transbank_webpay_plus_rest&tbk_tab=options'));
            }

            include_once __DIR__ . '/views/admin/options-tabs.php';
        }, null);

        add_submenu_page('woocommerce', __('Configuración de Webpay Plus', 'transbank_wc_plugin'), 'Webpay Oneclick', 'administrator', 'transbank_webpay_oneclick_rest', function () {
            wp_redirect(admin_url('admin.php?page=wc-settings&tab=checkout&section=transbank_oneclick_mall_rest&tbk_tab=options'));
        }, null);
    });
}

function registerPluginActionLinks()
{
    add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($actionLinks) {
        $webpaySettingsLink = sprintf(
            '<a href="%s">%s</a>',
            admin_url('admin.php?page=wc-settings&tab=checkout&section=transbank_webpay_plus_rest'),
            'Configurar Webpay Plus'
        );
        $oneclickSettingsLink = sprintf(
            '<a href="%s">%s</a>',
            admin_url('admin.php?page=wc-settings&tab=checkout&section=transbank_oneclick_mall_rest'),
            'Configurar Webpay Oneclick'
        );
        $newLinks = [
            $webpaySettingsLink,
            $oneclickSettingsLink,
        ];

        return array_merge($actionLinks, $newLinks);
    });
}

function addTransbankStatusMetaBox(bool $hPosExists)
{
    if ($hPosExists) {
        $screen = wc_get_container()
            ->get(CustomOrdersTableController::class)
            ->custom_orders_table_usage_is_enabled()
            ? wc_get_page_screen_id('shop-order')
            : 'shop_order';

        add_meta_box(
            'transbank_check_payment_status',
            __('Verificar estado del pago', 'transbank_wc_plugin'),
            function ($post_or_order_object) {
                $order = ($post_or_order_object instanceof WP_Post)
                    ? wc_get_order($post_or_order_object->ID)
                    : $post_or_order_object;

                $orderId = $order->get_id();
                renderTransactionStatusMetaBox($orderId);
            },
            $screen,
            'side',
            'core'
        );
    } else {
        add_meta_box('transbank_check_payment_status', __('Verificar estado del pago', 'transbank_wc_plugin'), function ($post) {
            $order = new WC_Order($post->ID);
            $orderId = $order->get_id();
            renderTransactionStatusMetaBox($orderId);
        }, 'shop_order', 'side', 'core');
    }
}

function renderTransactionStatusMetaBox(int $orderId)
{
    $viewData = [];
    $transaction = TbkFactory::createTransactionService()->findFirstByOrderId($orderId);

    if ($transaction) {
        $viewData = [
            'viewData' => [
                'orderId' => $orderId,
                'token' => $transaction->token,
                'buyOrder' => $transaction->buy_order
            ]
        ];
    }

    (new Template())->render('admin/order/transaction-status.php', $viewData);
}

function activateTransbankModule()
{
    try {
        DatabaseTableInstaller::createTableIfNeeded();
        DatabaseTableInstaller::checkTables();
        GatewaySettingsInstaller::installDefaultsIfMissing();
        ConfigMigrator::maybeMigrate();
    } catch (Throwable $e) {
        $logger = TbkFactory::createLogger();
        $logger->logError('Error al activar el plugin de Transbank: ' . $e->getMessage());
        wp_die(
            'No se pudo activar el plugin de Transbank. Error: ' . esc_html($e->getMessage()),
            'Error de activación',
            ['back_link' => true]
        );
    }
}

function transbank_rest_remove_database()
{
    DatabaseTableInstaller::deleteTable();
}



function transbank_rest_before_cart()
{
    SessionMessageHelper::printMessage();
}

function transbank_rest_check_cancelled_checkout()
{
    $cancelledOrder = $_GET['transbank_cancelled_order'] ?? false;
    $cancelledWebpayPlusOrder = $_GET['transbank_webpayplus_cancelled_order'] ?? false;
    if ($cancelledWebpayPlusOrder) {
        wc_print_notice(__('Cancelaste la transacción durante el formulario de Webpay Plus.', 'transbank_wc_plugin'), 'error');
    }
    if ($cancelledOrder) {
        wc_print_notice(__('Cancelaste la inscripción durante el formulario de Webpay.', 'transbank_wc_plugin'), 'error');
    }
}
